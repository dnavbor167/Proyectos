# PSR Container

This repository holds all interfaces/classes/traits related to [PSR-11](https://github.com/container-interop/fig-standards/blob/master/proposed/container.md).

Note that this is not a container implementation of its own. See the specification for more details.
